<?php

class TaskStatus extends ObjectModel

{

	public $title;
	
	public $description;
	

	/** @var string Name */

    /**

     * @see ObjectModel::$definition

     */

    public static $definition = array(

        'table' => 'ns_etask_type',
        'primary' => 'id_etask_type',
        'multilang' => FALSE,
        'fields' => array(            		
            'title'=>array('type' => self::TYPE_STRING, 'validate' => 'isCatalogName', 'required' => true, 'size' => 228),            
			'description'=>array('type' =>self::TYPE_HTML, 'validate' => 'isCleanHtml', 'required' =>true),               			

        ),

    );

	
	public static function loadById($id_etask_type){	
	
	$result = Db::getInstance()->getRow('
            SELECT *
            FROM `'._DB_PREFIX_.'ns_etask_type` at

            WHERE at.`id_etask_type` = '.(int)$id_etask_type

        );   
        	
		return $result['title'];	
	
	}	

	public static function getAllStatus()

	{

	    $sql='';

	    $id_lang = (int)Context::getContext()->language->id; 

		$dbquery = new DbQuery();

		$dbquery->select('*');
		$dbquery->from('ns_etask_type', 'd');	
		$orders = Db::getInstance(_PS_USE_SQL_SLAVE_)->executeS($dbquery->build());	

		return $orders;		

	}	



    

	

	

}



