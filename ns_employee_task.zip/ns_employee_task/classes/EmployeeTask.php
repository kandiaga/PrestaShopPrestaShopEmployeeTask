<?php
class EmployeeTask extends ObjectModel
{
	
	/** @var string Name */
	public $title;
	/** @var string Name */
	public $assigned_to;
	/** @var string Name */
	public $task_image;			public $priority;		public $comment;
	    public $department;
    public $id_author;		public $id_etask_type;		public $created_date;		public $due_date;
	
    /**
     * @see ObjectModel::$definition
     */
    public static $definition = array(
        'table' => 'ns_employee_task',
        'primary' => 'id_ns_employee_task',
        'multilang' => FALSE,
        'fields' => array(
            'title'=>array('type' => self::TYPE_STRING, 'validate' => 'isCatalogName', 'required' => true, 'size' => 128),
			'assigned_to'=>array('type' => self::TYPE_STRING, 'required' => true, 'size' => 128),				             'comment'=>array('type' =>self::TYPE_HTML, 'validate' => 'isCleanHtml', 'required' =>true),            'priority'=>array('type' => self::TYPE_INT, 'validate' => 'isNullOrUnsignedId', 'required' => true),            'task_image'=>array('type' => self::TYPE_STRING, 'validate' => 'isCatalogName', 'size' => 32),             'department'=>array('type' => self::TYPE_STRING, 'validate' => 'isCatalogName', 'size' =>128),            'id_etask_type'=>array('type' => self::TYPE_INT, 'validate' => 'isNullOrUnsignedId', 'required' => true), 			'id_author'=>array('type' => self::TYPE_INT, 'validate' => 'isNullOrUnsignedId', 'required' => true),            'created_date' => array('type' => self::TYPE_DATE, 'validate' => 'isDate'),			'due_date' => array('type' => self::TYPE_DATE, 'validate' => 'isDate'),           	
        ),
    );
	
    public static function loadByIdProduct($id_ns_employee_task){
        $result = Db::getInstance()->getRow('
            SELECT *
            FROM `'._DB_PREFIX_.'ns_employee_task` banner
            WHERE banner.`id_ns_employee_task` = '.(int)$id_ns_employee_task
        );
        
        return new EmployeeTask($result['id_ns_employee_task']);
    }
	
	/*get all tasks */	
	
	public function getAllTasks()
	{
	    $sql='';
	    $id_lang = (int)Context::getContext()->language->id; 				$id_employee=(int)Context::getContext()->employee->id;		$employee = new Employee($id_employee);		$id_profile=(int)$employee->id_profile;
		$dbquery = new DbQuery();
		$dbquery->select('d.`id_ns_employee_task` AS `id_ns_employee_task`, d.`title` AS `title`, d.`assigned_to` AS `assigned_to`, d.`due_date` AS `due_date`,		CONCAT(LEFT(`firstname`,150), \' \', `lastname` ) AS `ename`		');
		$dbquery->from('ns_employee_task', 'd'); 		if($id_profile!=1){        $dbquery->where('d.`assigned_to` ='.$id_employee);        }		        $dbquery->leftJoin('employee', 'e', 'e.id_employee= d.`assigned_to`');		        $dbquery->orderBy('d.`id_ns_employee_task`  DESC');		
		$orders = Db::getInstance(_PS_USE_SQL_SLAVE_)->executeS($dbquery->build());			
		return $orders;	
	}	
	/**	 * Return list of employees	 */	public static function getEmployees()	{	   		return Db::getInstance()->executeS('			SELECT `id_employee`, 			CONCAT(LEFT(`firstname`,150), \' \', `lastname` ) AS `ename`			FROM `'._DB_PREFIX_.'employee`			WHERE `active` = 1			ORDER BY `lastname` ASC		');	}		public static function getEmployeeName($id_employee)	{	   		$result=Db::getInstance()->getRow('			SELECT `id_employee`, 			CONCAT(LEFT(`firstname`,150), \' \', `lastname` ) AS `ename`			FROM `'._DB_PREFIX_.'employee`			WHERE `id_employee` ='.(int)$id_employee					);						return $result['ename'];	}					public static function getProfile($id_profile, $id_lang = null)	{		if (!$id_lang)			$id_lang = Configuration::get('PS_LANG_DEFAULT');		$result = Db::getInstance(_PS_USE_SQL_SLAVE_)->getRow('			SELECT `name`			FROM `'._DB_PREFIX_.'profile` p			LEFT JOIN `'._DB_PREFIX_.'profile_lang` pl ON (p.`id_profile` = pl.`id_profile`)			WHERE p.`id_profile` = '.(int)$id_profile.'			AND pl.`id_lang` = '.(int)$id_lang		);				return $result['name'];	}
	
	    public function processImage($FILES,$id) {
 
            if (isset($FILES['task_image']) && isset($FILES['task_image']['tmp_name']) && !empty($FILES['task_image']['tmp_name'])) {
                if ($error = ImageManager::validateUpload($FILES['task_image'], 4000000))
                    return $message='Invalid image';
                else {
                    $ext = substr($FILES['task_image']['name'], strrpos($FILES['task_image']['name'], '.') + 1);
                    $file_name = $id . '.' . $ext;


                    $path = _PS_MODULE_DIR_ .'ns_employee_task/uploads/' . $file_name;
                  

                    if (!move_uploaded_file($FILES['task_image']['tmp_name'], $path))
                        return $message='An error occurred while attempting to upload the file.';
                    else {
                        $posts_types =ImageType::getImagesTypes('products');
                        foreach ($posts_types as  $image_type)
			{
                                     $dir = _PS_MODULE_DIR_ .'ns_employee_task/uploads/'.$id.'-'.stripslashes($image_type['name']).'.jpg';
                                        if (file_exists($dir))
						unlink($dir);
			}
			foreach ($posts_types as $image_type)
			{
                                    ImageManager::resize($path,_PS_MODULE_DIR_ .'ns_employee_task/uploads/'.$id.'-'.stripslashes($image_type['name']).'.jpg',
                                        (int)$image_type['width'], (int)$image_type['height']
                                        );
			}
                    }
                }
            } 		
			
    }
	
	
	
	
}

