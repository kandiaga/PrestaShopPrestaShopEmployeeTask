<?php
if (!defined('_PS_VERSION_')){
  exit;
 } 
require_once(dirname(__FILE__) . '/classes/EmployeeTask.php');  
require_once(dirname(__FILE__) . '/classes/TaskStatus.php');


  class ns_employee_task  extends Module
  
  { 
  
  public function __construct()
  {
    $this->name = 'ns_employee_task';
    $this->tab = 'front_office_features';
    $this->version = '1.0.0';
    $this->author = 'NdiagaSoft';
    $this->need_instance = 0;
    $this->ps_versions_compliancy = array('min' => '1.5', 'max' =>_PS_VERSION_);
    $this->bootstrap = true;
 
    parent::__construct();
 
    $this->displayName = $this->l('NS Employee Task');
    $this->description = $this->l('Create a task and assign it to an employee.');
 
    $this->confirmUninstall = $this->l('Are you sure you want to uninstall?'); 
    
  }
  
  
  
  public function install()
{
  if (Shop::isFeatureActive())
    Shop::setContext(Shop::CONTEXT_ALL);
	$sql = array();
	
        $sql[] = 'CREATE TABLE IF NOT EXISTS `'._DB_PREFIX_.'ns_employee_task` (
                  `id_ns_employee_task` int(10) unsigned NOT NULL AUTO_INCREMENT,                  
				  `title` varchar(250) NOT NULL,
				  `assigned_to` varchar(250) NOT NULL,
				  `department` varchar(250) NOT NULL,
				  `priority` int(11) NOT NULL,
				  `id_author` int(11) NOT NULL,				  
				  `comment`  TEXT NOT NULL,
				  `task_image` varchar(250), 
                  `id_etask_type` int(11) NOT NULL,
                  `created_date` datetime NOT NULL,	
                  `due_date`  datetime NOT NULL,				  
                  PRIMARY KEY (`id_ns_employee_task`)
                ) ENGINE='._MYSQL_ENGINE_.' DEFAULT CHARSET=utf8';
	
	$sql[] = 'CREATE TABLE IF NOT EXISTS `'._DB_PREFIX_.'ns_task_todo` (
                  `id_ns_employee_task` int(10) NOT NULL,				  
				  `id_employee` int(11) NOT NULL,				                   				  
                  PRIMARY KEY (`id_ns_employee_task`,`id_employee`)
                ) ENGINE='._MYSQL_ENGINE_.' DEFAULT CHARSET=utf8';
	
    $sql[] = 'CREATE TABLE IF NOT EXISTS `'._DB_PREFIX_.'ns_etask_type` (
                  `id_etask_type` int(10) unsigned NOT NULL AUTO_INCREMENT,                  
				  `title` varchar(250) NOT NULL,				 
				  `description`  TEXT NOT NULL,				                  				  
                  PRIMARY KEY (`id_etask_type`)
                ) ENGINE='._MYSQL_ENGINE_.' DEFAULT CHARSET=utf8';
	 
    $sql[]="INSERT INTO `". _DB_PREFIX_ ."ns_etask_type` (`id_etask_type`, `title`, `description`) VALUES
            (1, 'To Do', '	\r\n    just created'),
            (2, 'Work in Progress', '	\r\n    The is already assigned to an employee and being processed.'),
            (3, 'Admin Reviewing', 'The  employee has   already  finished the task has submit it back to the assigner for validation.\r\n    '),
            (4, 'Done', 'The task is already finished by the employee and was verified by admin.\r\n	\r\n    ')";	 
 
  return (parent::install() 
    && $this->registerHook('backOfficeFooter')
    && $this->registerHook('dashboardZoneTwo')   	  
    && $this->runSql($sql)
    && Configuration::updateValue('EMPLOYEE_TASK_INFO_TEXT','You have a new task') 	
  );   
 
  return true;
  
}
       public function uninstall()
    {
        $sql = array();
	
        $sql[] = 'DROP TABLE IF EXISTS `'._DB_PREFIX_.'ns_employee_task`';
		$sql[] = 'DROP TABLE IF EXISTS `'._DB_PREFIX_.'ns_task_todo`';
		$sql[] = 'DROP TABLE IF EXISTS `'._DB_PREFIX_.'ns_etask_type`';
		
		if (!parent::uninstall()||
		    !$this->runSql($sql)||						
            !Configuration::deleteByName('EMPLOYEE_TASK_INFO_TEXT')			
           )
                return false;
           $this->emptyUploads();
           return true;
    }
	
	
   public function runSql($sql) {
        foreach ($sql as $s) {
			if (!Db::getInstance()->Execute($s)){
				return FALSE;
			}
        }
        
        return TRUE;
    }	
  
        public function getContent()
    {
          $output = null;
		  
		 
		
		$id_employee=(int)Context::getContext()->employee->id;
		$employee = new Employee($id_employee);
		$id_profile=(int)$employee->id_profile;
		  
	   if($id_profile==1)	  
	  {  
		  $output.=$this->addMenu();
	  
      }

      /* non admin list */
	else  
		{
		
		   $output.=$this->addMenuSecond();			   
		   
		} 	  
		  
		 $output.=$this->addNewTask();		 
		 
		 
		  
		    if (Tools::isSubmit('submit'.$this->name))
      {
        $my_module_name =strval(Tools::getValue('EMPLOYEE_TASK_INFO_TEXT'));
		$alert_employee_by_email=Tools::getValue('alert_employee_by_email');
		$display_message_in_bo_footer_area=Tools::getValue('display_message_in_bo_footer_area');
		$display_message_in_dashboard=Tools::getValue('display_message_in_dashboard');
		
        if (!$my_module_name || empty($my_module_name) || !Validate::isGenericName($my_module_name))
            $output .= $this->displayError($this->l('Invalid Configuration value'));
        else
        {
            Configuration::updateValue('EMPLOYEE_TASK_INFO_TEXT', $my_module_name);
			Configuration::updateValue('alert_employee_by_email', $alert_employee_by_email);
            Configuration::updateValue('display_message_in_bo_footer_area', $display_message_in_bo_footer_area);	
            Configuration::updateValue('display_message_in_dashboard', $display_message_in_dashboard);				
			
			
			
		
            $output.= $this->displayConfirmation($this->l('Settings updated'));
        }
      }  
	  
		
     if (Tools::isSubmit('viewAddNewTask') && $id_profile==1){
	 
	     $output.='</br>'.$this->renderAddNewTask();
	 
	 
	    }	  

		elseif(Tools::isSubmit('viewTaskList')){
		
	     $output.='</br>'.$this->renderList();	 
	 
	    }
		
		elseif(Tools::isSubmit('viewTaskStatuses')){
		
	     $output.='</br>'.$this->renderTaskStatuses();	 
	 
	    }
		

        elseif(Tools::isSubmit('viewNsAdvertize')){
	 
	    $output.='</br>'.$this->displayAdvertising();	 
	 
	    }		

         elseif (Tools::isSubmit('deletens_employee_task') && Tools::isSubmit('id_ns_employee_task'))
		{
		 $banner=new EmployeeTask((int)Tools::getValue('id_ns_employee_task'));
               $banner->delete();	
               $this->emptyCurrentImage(Tools::getValue('id_ns_employee_task'));
			   
               $output.= $this->displayConfirmation($this->l('Task Deleted successfully!'));
               			   
		} 
		
		 elseif (Tools::isSubmit('deletens_etask_type') && Tools::isSubmit('id_etask_type'))
		{
		       $TaskStatus=new TaskStatus((int)Tools::getValue('id_etask_type'));
               $TaskStatus->delete();      
			   
               $output.= $this->displayConfirmation($this->l('Task Status Deleted successfully!'));
               			   
		} 
		
		
		

           elseif (Tools::isSubmit('updatens_employee_task') && Tools::isSubmit('id_ns_employee_task'))
		{
		 
		 $output.=$this->renderUpdateTask();
               	 
		}  
		
		  
		elseif (Tools::isSubmit('viewns_employee_task') && Tools::isSubmit('id_ns_employee_task'))
		{
		$output.=$this->renderViewTask().'</br>';	
             
	  if(Tools::isSubmit('submitUpdateTaskStatus') && Tools::isSubmit('id_ns_employee_task')!='' && Tools::isSubmit('id_etask_type')!=''){

		   $id_ns_employee_task=(int)Tools::getValue('id_ns_employee_task');
		   $id_etask_type=(int)Tools::getValue('id_etask_type');
		   
		   $sql= 'UPDATE`'._DB_PREFIX_.'ns_employee_task` SET `id_etask_type`=\''.pSQL($id_etask_type).'\'
		   
		              WHERE `id_ns_employee_task`='.$id_ns_employee_task;

                    Db::getInstance()->execute($sql);
					
					
			if(Configuration::get('alert_employee_by_email')==1){	
                  $Task=new EmployeeTask($id_ns_employee_task);		
				  $employee_author=new Employee($Task->id_author);	
				  $employee_assigned_to=new Employee($Task->assigned_to);	
				  $message_subject=$this->l('Hello, the task you assigned to:  ').$employee_assigned_to->firstname.' '.$employee_assigned_to->lastname;	
				  $message_subject.=' '.$this->l(' has a status update. ');				
				  $base_dir_nka=Tools::getHttpHost(true).__PS_BASE_URI__; 		
				  $admin_dir=$this->after_last('/', _PS_ADMIN_DIR_);      
				  $href=$base_dir_nka.$admin_dir.'/'.AdminController::$currentIndex.'&configure='.$this->name.'&save'.$this->name.'&token='.Tools::getAdminTokenLite('AdminModules');	
				  $href.='&id_ns_employee_task='.$id_ns_employee_task.'&viewns_employee_task';					
				  $task_link_admin= '<a href="'.$href.'">'.$this->l('Visit Shop').'</a>';				
				  $message_subject.='<br/>'.$this->l('Please  visit  your task from this link: ').$task_link_admin;    
				  $message_title =$this->l('Notification about Task  Status'); 	 		
                   $email=$employee_author->email;		   		
		    $this->sendMail($email,$message_title,$message_subject);		   
		}				
					
				

		   }

     		
		}
        
		elseif (Tools::isSubmit('viewTasksDone')){	 
	     $output.='</br>'.$this->renderList();
	 
	    }	 
        elseif(Tools::isSubmit('viewMyToDoList')){		
	     $output.='</br>'.$this->renderList();	 
	    }		
		 
		elseif(Tools::isSubmit('viewSettings') && $id_profile==1){		
	     $output.='</br>'.$this->displayForm();	 
	    }	 
		 
		 
		else{
		
	   $output.='<p class="alert alert-warning">'.$this->l('Navigate with the menu above.').'</p>';
		
		} 
		  
		
		
		
		   
			
            return $output;
    }  

	
	
		public function addMenu(){
	
	$button= '<div class="panel">'; 
    $button .= '<a href="'.$this->context->link->getAdminLink('AdminModules', false).'&viewSettings&configure='.$this->name.'&token='.Tools::getAdminTokenLite('AdminModules').'">
               <button class="btn btn-default">'.$this->l('Settings').'</button>
               </a>';	 	
	$button .= '<a href="'.$this->context->link->getAdminLink('AdminModules', false).'&viewAddNewTask&configure='.$this->name.'&token='.Tools::getAdminTokenLite('AdminModules').'">
               <button class="btn btn-default">'.$this->l('Add New Task').'</button>
               </a>';
    $button .= '<a href="'.$this->context->link->getAdminLink('AdminModules', false).'&viewTaskList&configure='.$this->name.'&token='.Tools::getAdminTokenLite('AdminModules').'">
               <button class="btn btn-default">'.$this->l('Task List').'</button>
               </a>';
	$button .= '<a href="'.$this->context->link->getAdminLink('AdminModules', false).'&viewTaskStatuses&configure='.$this->name.'&token='.Tools::getAdminTokenLite('AdminModules').'">
               <button class="btn btn-default">'.$this->l('Task Statuses').'</button>
               </a>';		   
	$button .= '<a style="float:right;" href="'.$this->context->link->getAdminLink('AdminModules', false).'&viewNsAdvertize&configure='.$this->name.'&token='.Tools::getAdminTokenLite('AdminModules').'">
               <button class="btn btn-default">'.$this->l('Our Other Modules').'</button>
               </a>';		   
    	   
	 $button.='</div>';
	
	 return $button;
	 
	 
	}
	
	
	public function addMenuSecond(){
	
	$button= '<div class="panel">';
	
	$button .= '<a href="'.$this->context->link->getAdminLink('AdminModules', false).'&viewMyToDoList&configure='.$this->name.'&token='.Tools::getAdminTokenLite('AdminModules').'">
               <button class="btn btn-default">'.$this->l('My To Do List').'</button>
               </a>';
    $button .= '<a href="'.$this->context->link->getAdminLink('AdminModules', false).'&viewTasksDone&configure='.$this->name.'&token='.Tools::getAdminTokenLite('AdminModules').'">
               <button class="btn btn-default">'.$this->l('Tasks Done').'</button>
               </a>';  
    		   
	 $button.='</div>';
	
	 return $button;
	 
	 
	}
	
	
	
	

// list
      	public function renderList()
	{
		
		
		$id_employee=(int)Context::getContext()->employee->id;
		$employee = new Employee($id_employee);
		$id_profile=(int)$employee->id_profile;
		
		
		
		$fields_list = array(
		
		   'id_ns_employee_task' => array(
				'title' => $this->l('ID'),
				'search' => false,
			),
			'title' => array(
				'title' => $this->l('Title'),
				'search' => false,
			),			
			'ename' => array(
				'title' => $this->l('Assigned to'),
				'search' => false,
			),			
			'due_date' => array(
				'title' => $this->l('Due Date'),
				'search' => false,
			)
		);

		if (!Configuration::get('PS_MULTISHOP_FEATURE_ACTIVE'))
			unset($fields_list['shop_name']);
		$helper_list = New HelperList();
		$helper_list->module = $this;
		$helper_list->title = $this->l('Employee Tasks: Last added tasks');
		$helper_list->shopLinkType = '';
		$helper_list->no_link = true;
		$helper_list->show_toolbar = true;
		$helper_list->simple_header = false;
		$helper_list->identifier = 'id_ns_employee_task';
		$helper_list->table = 'ns_employee_task';
		$helper_list->currentIndex = $this->context->link->getAdminLink('AdminModules', false).'&configure='.$this->name;
		$helper_list->token = Tools::getAdminTokenLite('AdminModules');
		if($id_profile==1){
		$helper_list->actions = array('view','edit','delete');
		}
		else
		{
		  $helper_list->actions = array('view');
		}
		$helper_list->bulk_actions = array(
			'select' => array(
				'text' => $this->l('Change order status'),
				'icon' => 'icon-refresh',				
			)
		); 		

		// This is needed for displayEnableLink to avoid code duplication
		$this->_helperlist = $helper_list;

		/* Retrieve list data */
		$order=new EmployeeTask();
		$orders=$order->getAllTasks();
		$helper_list->listTotal = count($order->getAllTasks());

		/* Paginate the result */
		$page = ($page = Tools::getValue('submitFilter'.$helper_list->table)) ? $page : 1;
		$pagination = ($pagination = Tools::getValue($helper_list->table.'_pagination')) ? $pagination : 50;
		$orders = $this->paginateOrderProducts($orders, $page, $pagination);

		return $helper_list->generateList($orders, $fields_list);
		
	}

  
  
  
   public function paginateOrderProducts($orders, $page = 1, $pagination = 50)
	{
		if(count($orders) > $pagination)
			$orders= array_slice($orders, $pagination * ($page - 1), $pagination);

		return $orders;
	}  
  

//list	
  
     
    
    public function hookDisplayHeader()
   {
        $this->context->controller->addCSS(($this->_path).'css/ns_employee_task.css', 'all');
		$this->context->controller->addJS(($this->_path).'js/ns_employee_task.js', 'all');
		//
		
		$this->context->controller->addCSS(($this->_path).'css/prettyslider-responsive.css', 'all');		
		$this->context->controller->addCSS(($this->_path).'css/prettyslider.css', 'all');
		$this->context->controller->addJS(($this->_path).'js/prettyslider.js', 'all');
    }  	
	
   
   
    public function renderTaskStatuses(){
	
	 $all_status=TaskStatus::getAllStatus();

    $this->context->smarty->assign(

      array(
		  'url_submit_add'=>AdminController::$currentIndex.'&viewTaskStatuses&configure='.$this->name.'&token='.Tools::getAdminTokenLite('AdminModules'),
          'message_alert'=>$this->addNewStatus(),
          'status_list'=>$all_status,
		  'token'=>Tools::getAdminTokenLite('AdminModules'),
		  'url_back'=>AdminController::$currentIndex.'&configure='.$this->name.'&token='.Tools::getAdminTokenLite('AdminModules'),
            )
         );

		return $this->display(__FILE__, 'views/templates/admin/renderAddTaskStatus.tpl');
	
	
	}	
	
    public function addNewStatus(){
	
	$id_lang=(int)Context::getContext()->language->id;
	
	$messaege_alert='';
	

     if(Tools::isSubmit('submitAddnewTaskStatus')){
	 
        $TaskStatus =new TaskStatus();
        $TaskStatus->title=Tools::getValue('title');
		$TaskStatus->description=Tools::getValue('description');	

        if(!$TaskStatus->add())

		   {
		   $messaege_alert="An error has occurred: Can\'t save the current object";
		   }
        else{
             $messaege_alert="Your Staus has been successfully added.";
		    }
      }
	  
	    return $messaege_alert;

   }	
   
   
     public function renderViewTask(){  
	 
	    $id_lang = (int)Context::getContext()->language->id; 
	     $all_status=TaskStatus::getAllStatus();
		
		$id_employee=(int)Context::getContext()->employee->id;
		$employee = new Employee($id_employee);
		$id_profile=(int)$employee->id_profile;
	 
    $id_ns_employee_task=(int)Tools::getValue('id_ns_employee_task');
    $task=new EmployeeTask($id_ns_employee_task);	
    $this->context->smarty->assign(
      array(	   
          'Task'=>$task,
          'id_profile'=>$id_profile,
          'id_employee'=>$id_employee,
          'status_list'=>$all_status,
          'id_lang'=>$id_lang,		  
		  'url_back'=>AdminController::$currentIndex.'&configure='.$this->name.'&token='.Tools::getAdminTokenLite('AdminModules')
		        
            )
           );  
  
  return $this->display(__FILE__, 'views/templates/admin/view_task.tpl');
  }
   
  public function  renderUpdateTask(){
  
       $id_lang=(int)$this->context->language->id;
	   
        $output='';
	 
        $id_ns_employee_task=(int)Tools::getValue('id_ns_employee_task');
        $TaskObj=new EmployeeTask($id_ns_employee_task);
		$title=Tools::getValue('task_title');	   
	    $priority=Tools::getValue('priority');
	    $comment=Tools::getValue('comment');
	    $task_image=Tools::getValue('task_image');	   
	   $department=Tools::getValue('department');
	   $id_etask_type=(int)Tools::getValue('id_etask_type');;
	   $created_date=Tools::getValue('created_date');
	   $due_date=Tools::getValue('due_date');
	   $assigned_to=Tools::getValue('assigned_to');   
		
  if(Tools::isSubmit('submitUpdateTask') && $id_ns_employee_task!='' && $title!='' && $assigned_to!='')
	  
	  {
        
		$TaskObj->title=$title;			
		$TaskObj->priority=$priority;
		$TaskObj->comment=$comment;
		$TaskObj->task_image=$task_image;
		$TaskObj->department=$department;
		$TaskObj->id_etask_type=$id_etask_type;
		$TaskObj->created_date=$created_date;
		$TaskObj->due_date=$due_date;
		$TaskObj->assigned_to=$assigned_to;		
		$TaskObj->id_author=(int)Context::getContext()->employee->id;
       
	    $TaskObj->update();
	   
	   $output=$this->displayConfirmation($this->l('Your Task has been successfully updated.'));
	   
  } 
  else {$output=$this->displayError($this->l('All Field are required'));} 
     

    $Profiles=Profile::getProfiles($this->context->language->id);
	$employees=EmployeeTask::getEmployees();	 
	   
    $this->context->smarty->assign(
      array(	      
		  'id_ns_employee_task'=>$id_ns_employee_task,
          'TaskObj'=>$TaskObj,
		  'output'=>$output,
		  'profiles'=>$Profiles,
		  'employees'=>$employees,
		  'id_lang'=>$id_lang,
		  'token'=>Tools::getAdminTokenLite('AdminModules'), 
          'update_token'=>Tools::getAdminTokenLite('AdminModules'),
          'url_back'=>AdminController::$currentIndex.'&configure='.$this->name.'&token='.Tools::getAdminTokenLite('AdminModules')          
            )
            );  
   
    return $this->display(__FILE__, 'views/templates/admin/edit_task.tpl');
	
   }
   
    //emptying the uploads Directory after uninstall 
  public function emptyUploads(){   
     foreach (new DirectoryIterator('../modules/ns_employee_task/uploads') as $file) 
	 if ($file!=='index.php') {
     @unlink('../modules/ns_employee_task/uploads/'.$file);  
     }	 
  }  
   
   
   
    //emptying the uploads Directory after uninstall 
  public function emptyCurrentImage($id){   
     foreach (new DirectoryIterator('../modules/ns_employee_task/uploads') as $file) 
	 if (strpos($file, $id) !== false) {
     @unlink('../modules/ns_employee_task/uploads/'.$file);  
    }	 
  }  
   
  
  
  //for employee email 
  
  	   public function displayForm()
  {
    // Get default language
    $default_lang = (int)Configuration::get('PS_LANG_DEFAULT');
     
    // Init Fields form array
    $fields_form[0]['form'] = array(
        'legend' => array(
            'title' => $this->l('Settings'),
			'icon' => 'icon-cogs'
        ),
        'input' => array(
            array(
                'type' => 'text',
                'label' => $this->l('Message Alert Text:'),
                'name' => 'EMPLOYEE_TASK_INFO_TEXT',
                'size' => 20,
                'required' => true
            ),
			
			array(
				'type' => 'switch',
						'label' => $this->l('Alert the Employee by email?'),
						'name' => 'alert_employee_by_email',
						'desc' => $this->l('You can send an email to the employee you assigned a task to inform him.'),
						'is_bool' => true,
						'values' => array(
							array(
								'id' => 'active_on',
								'value' => 1,
								'label' => $this->l('Yes')
							),
							array(
								'id' => 'active_off',
								'value' => 0,
								'label' => $this->l('No')
							)
						),
					),
				

                array(
				'type' => 'switch',
						'label' => $this->l('Display the alert Message in Admin Dashboard?'),
						'name' => 'display_message_in_dashboard',
						'desc' => $this->l('Display or not  the message in the Dashboard to inform the employees.'),
						'is_bool' => true,
						'values' => array(
							array(
								'id' => 'active_on',
								'value' => 1,
								'label' => $this->l('Yes')
							),
							array(
								'id' => 'active_off',
								'value' => 0,
								'label' => $this->l('No')
							)
						),
					),

                  array(
				'type' => 'switch',
						'label' => $this->l('Display in the BO footer area?'),
						'name' => 'display_message_in_bo_footer_area',
						'desc' => $this->l('Choose wither or not to show this alert in the BO footer area.'),
						'is_bool' => true,
						'values' => array(
							array(
								'id' => 'active_on',
								'value' => 1,
								'label' => $this->l('Yes')
							),
							array(
								'id' => 'active_off',
								'value' => 0,
								'label' => $this->l('No')
							)
						),
					)					
					
					
					
        ),
        'submit' => array(
            'title' => $this->l('Save'),           
        )
    );
     
    $helper = new HelperForm();
     
    // Module, token and currentIndex
    $helper->module = $this;
    $helper->name_controller = $this->name;
    $helper->token = Tools::getAdminTokenLite('AdminModules');
    $helper->currentIndex = AdminController::$currentIndex.'&configure='.$this->name;
     
    // Language
    $helper->default_form_language = $default_lang;
    $helper->allow_employee_form_lang = $default_lang;
     
    // Title and toolbar
    $helper->title = $this->displayName;
    $helper->show_toolbar = true;        // false -> remove toolbar
    $helper->toolbar_scroll = true;      // yes - > Toolbar is always visible on the top of the screen.
    $helper->submit_action = 'submit'.$this->name;
    $helper->toolbar_btn = array(
        'save' =>
        array(
            'desc' => $this->l('Save'),
            'href' => AdminController::$currentIndex.'&configure='.$this->name.'&save'.$this->name.
            '&token='.Tools::getAdminTokenLite('AdminModules'),
        ),
        'back' => array(
            'href' => AdminController::$currentIndex.'&token='.Tools::getAdminTokenLite('AdminModules'),
            'desc' => $this->l('Back to list')
        )
    );
     
    // Load current value
    $helper->fields_value['EMPLOYEE_TASK_INFO_TEXT'] = Configuration::get('EMPLOYEE_TASK_INFO_TEXT');
	$helper->fields_value['alert_employee_by_email'] = Configuration::get('alert_employee_by_email');
	$helper->fields_value['display_message_in_bo_footer_area'] = Configuration::get('display_message_in_bo_footer_area');
	$helper->fields_value['display_message_in_dashboard'] = Configuration::get('display_message_in_dashboard');
	
	
     
    return $helper->generateForm($fields_form);
    } 
  

  
 
  
      public function displayAdvertising()
  {
		$html= '
		<br/>
		<fieldset>
			<legend><img src="'.$this->_path.'img/more.png" alt="" title="" /> '.$this->l('More Modules & Themes ').'</legend>	
			<iframe src="http://prestatuts.com/advertising/prestashop_advertising.html" width="100%" height="420px;" border="0" style="border:none;"></iframe>
			</fieldset>';
			
	   return $html;		
  }
  
  
  
  public function renderAddNewTask(){
  
        // Get default language
    $default_lang = (int)Configuration::get('PS_LANG_DEFAULT');
	
	$Profiles=Profile::getProfiles($this->context->language->id);
	$employees=EmployeeTask::getEmployees();
     
    // Init Fields form array
    $fields_form[0]['form'] = array(
        'legend' => array(
            'title' => $this->l('Add New Task'),
			'icon' => 'icon-pencil'
        ),
        'input' => array(
            array(
                'type' => 'text',
                'label' => $this->l('Title:'),
                'name' => 'task_title',
                'size' => 20,
                'required' => true,
				'hint' => $this->l('Invalid characters:').' &lt;&gt;;=#{}'
            ),		
					
			array(
					'type' => 'textarea',
						'label' => $this->l('Task Description:'),
						'name' => 'comment',						
						'rows' => 10,
                        'cols' => 62,
						'class' => 'rte',
						'autoload_rte'=>true,
						'required'=>true,
						'desc' => $this->l('Add  a  description of this task.'),
						'hint' => $this->l('Invalid characters:').' &lt;&gt;;=#{}'
					),					
                    array(
					'type' => 'select',
					'label' => $this->l('Select a Department'),
					'name' => 'department',
					
					'options' => array(
						'query' =>$Profiles,
						'id' => 'id_profile',
						'name' => 'name'
						
					),
					'desc' => $this->l('Select the department you want to assign this task.'),
					'required'=>true,
					'hint' => $this->l('Invalid characters:').' &lt;&gt;;=#{}'
                      ),	
					
					array(
						'type' => 'date',
						'label' => $this->l('Start Date:'),
						'name' => 'created_date',
						'required'=>true,
						'desc' => $this->l('Add the start date in the format: 0000-00-00 '),
					),
					array(
						'type' => 'date',
						'label' => $this->l('Due date:'),
						'name' => 'due_date',
						'required'=>true,
						'desc' => $this->l('Add the task due date in the format: 0000-00-00'),
					),
                    array(
                        'type' => 'radio',
                        'label' => $this->l('Priority:'),
                        'name' => 'priority',
						'desc' => $this->l('Select the priority level.'),
                        'hint' => $this->l('Invalid characters:').' &lt;&gt;;=#{}',
                         'values' => array(
                         array(
                         'id' => 'low_priority',
                         'value' => 1,
                         'label' =>'&#9733;&#9734;&#9734;  :'.$this->l('Low'),
                             ),
                         array(
                        'id' => 'medium_priority',
                        'value' => 2,
                        'label' =>'&#9733;&#9733;&#9734;  :'.$this->l('Medium'),
                           ),
						   array(
                        'id' => 'high_priority',
                        'value' => 3,
                        'label' =>'&#9733;&#9733;&#9733;  :'.$this->l('High'),
                           ),
                            ),
                         ),					
					
					array(
						'type' => 'file',
						'label' => $this->l('Image:'),
						'name' => 'task_image',
						'class' => 'fixed-width-sm',
						'required'=>true,
						'desc' => $this->l('Add the Task associated image.'),
					),
                array(
					'type' => 'select',
					'label' => $this->l('Assign to'),
					'name' => 'assigned_to',
					
					'options' => array(
						'query' =>$employees,
						'id' => 'id_employee',
						'name' => 'ename',						
					),
					'desc' => $this->l('Select an employee and assign him this task.'),
					'required'=>true,
					'hint' => $this->l('Invalid characters:').' &lt;&gt;;=#{}'
                      ),				
					
					
        ),
        'submit' => array(
            'title' => $this->l('Save'),           
        )
    );
     
    $helper = new HelperForm();
     
    // Module, token and currentIndex
    $helper->module = $this;
    $helper->name_controller = $this->name;
    $helper->token = Tools::getAdminTokenLite('AdminModules');
    $helper->currentIndex = AdminController::$currentIndex.'&configure='.$this->name;
     
    // Language
    $helper->default_form_language = $default_lang;
    $helper->allow_employee_form_lang = $default_lang;
     
    // Title and toolbar
    $helper->title = $this->displayName;
    $helper->show_toolbar = true;        // false -> remove toolbar
    $helper->toolbar_scroll = true;      // yes - > Toolbar is always visible on the top of the screen.
    $helper->submit_action = 'submitAddNewTask';
    $helper->toolbar_btn = array(
        'save' =>
        array(
            'desc' => $this->l('Save'),
            'href' => AdminController::$currentIndex.'&configure='.$this->name.'&save'.$this->name.
            '&token='.Tools::getAdminTokenLite('AdminModules'),
        ),
        'back' => array(
            'href' => AdminController::$currentIndex.'&token='.Tools::getAdminTokenLite('AdminModules'),
            'desc' => $this->l('Back to list')
        )
    );
     
    // Load current value
    $helper->fields_value['task_title'] = Configuration::get('task_title');
	$helper->fields_value['comment'] = Configuration::get('comment',true);
	$helper->fields_value['priority'] = Configuration::get('priority');
	$helper->fields_value['task_image'] = Configuration::get('task_image');
	$helper->fields_value['department'] = Configuration::get('department');		
	$helper->fields_value['created_date'] = Configuration::get('created_date');
	$helper->fields_value['due_date'] = Configuration::get('due_date');
	$helper->fields_value['assigned_to'] = Configuration::get('assigned_to');
	
     
    return $helper->generateForm($fields_form);
	
   
   }
   
   
   	   public function addNewTask(){	
	   
	   $output='';
	   $id_lang=(int)Context::getContext()->language->id; 
	   
     if(Tools::isSubmit('submitAddNewTask')){ 

	   $title=Tools::getValue('task_title');	   
	   $priority=Tools::getValue('priority');
	   $comment=Tools::getValue('comment');
	   $task_image=Tools::getValue('task_image');	   
	   $department=Tools::getValue('department');
	   $id_etask_type=1;
	   $created_date=Tools::getValue('created_date');
	   $due_date=Tools::getValue('due_date');
	   $assigned_to=Tools::getValue('assigned_to');   
	   
	   
	   
	   
   if($title !='' && $assigned_to!='' ){
		
        $TaskObj =new EmployeeTask();
        
		$TaskObj->title=$title;			
		$TaskObj->priority=$priority;
		$TaskObj->comment=$comment;
		$TaskObj->task_image=$task_image;
		$TaskObj->department=$department;
		$TaskObj->id_etask_type=$id_etask_type;
		$TaskObj->created_date=$created_date;
		$TaskObj->due_date=$due_date;
		$TaskObj->assigned_to=$assigned_to;		
		$TaskObj->id_author=(int)Context::getContext()->employee->id;
		
    if(!$TaskObj->add()){$output= $this->displayError($this->l('An error has occurred: Can\'t save the current object'));	}
       else{
             $TaskObj->processImage($_FILES,$TaskObj->id);	
	    $image_url=$TaskObj->id.'-small_default.jpg';				
		$sql= 'UPDATE`'._DB_PREFIX_.'ns_employee_task` SET `task_image`=\''.pSQL($image_url).'\' 
		       WHERE `id_ns_employee_task`='.$TaskObj->id;                        
                  Db::getInstance()->execute($sql); 				  		
				  if(Configuration::get('alert_employee_by_email')==1){			
				  $employee_notify=new Employee((int)Tools::getValue('assigned_to'));	
				  $message_subject=$this->l('Hello ').$employee_notify->firstname.' '.$employee_notify->lastname;	
				  $message_subject.='<br/>'.Configuration::get('EMPLOYEE_TASK_INFO_TEXT');				
				  $base_dir_nka=Tools::getHttpHost(true).__PS_BASE_URI__; 		
				  $admin_dir=$this->after_last('/', _PS_ADMIN_DIR_);      
				  $href=$base_dir_nka.$admin_dir.'/'.AdminController::$currentIndex.'&configure='.$this->name.'&save'.$this->name.'&token='.Tools::getAdminTokenLite('AdminModules');	
				  $href.='&id_ns_employee_task='.$TaskObj->id.'&viewns_employee_task';					
				  $task_link_admin= '<a href="'.$href.'">'.$this->l('Visit Shop').'</a>';				
				  $message_subject.='<br/>'.$this->l('Please  visit  your task from this link: ').$task_link_admin;    
				  $message_title =$this->l('Notification about new  Task'); 	 		
                   $email=$employee_notify->email;		   		
		    $this->sendMail($email,$message_title,$message_subject);		   
		}		
		$output=$this->displayConfirmation($this->l('Your Task has been successfully added.'));
		
		}
		
		} else {$output=$this->displayError($this->l('All Field are required'));} 
      }   
	  
	  return $output;
   }      
   
   public  function after_last($nka, $inthat)    {     
   if (!is_bool($this->strrevpos($inthat, $nka)))     
	   return substr($inthat, $this->strrevpos($inthat, $nka)+strlen($nka));    
   }
    
	public  function strrevpos($instr, $needle) {  
	$rev_pos = strpos (strrev($instr), strrev($needle));   
	if ($rev_pos===false) return false;    
	else return strlen($instr) - $rev_pos - strlen($needle);   
	
	}
    	/*sending email to the client*/    	    
		
		
	public function sendMail($email,$message_title,$message_subject)
	{  	  
		$quote_image_url='';                  
		$to=$email;                    
		$notif_det_text=$this->l('Notification details');		
		$notif_det_date=$this->l('Sent on:');         		       
		$date = date('d/m/y');	      
		$base_dir_nka=Tools::getHttpHost(true).__PS_BASE_URI__; 	
		$html= '<a href="'.$base_dir_nka.'">'.$this->l('Visit Shop').'</a>';        
		return  Mail::Send($this->context->language->id,    
		'validation_conf',         
		Mail::l($message_title, $this->context->language->id),            
		array('{html}' => $html,                    
        		'{date}' => $date, 					
				'{base_dir_nka}'=>$base_dir_nka,				
				'{quote_image_url}'=>$quote_image_url,               
				'{message_title}'=>$message_title, 		                
				'{message_subject}'=>$message_subject,                
				'{username}'=>'', 	                       
				'{phone}'=>'', 						
				'{notif_det_text}'=>$notif_det_text,      
				'{notif_det_date}'=>$notif_det_date,		
				),                  
				pSQL($to),            
				null,                 
				null ,                
				null,                 
				null,                 
				null,                  
				dirname(__FILE__).'/mails/',           
				false,$this->context->shop->id              
				);            
	
	}			


    
	
	public function hookDashboardZoneTwo($params){
		
		$html='<div class="panel">';
		
		$url='index.php?controller=AdminModules&configure='.$this->name.'&token='.Tools::getAdminTokenLite('AdminModules');
		$html.='<a  href="'.$url.'">'.$this->l('My Tasks').'</a>';
		
		$html.='</div>';
		
		return $html;
	}
	
	public function hookBackOfficeFooter($params){
		
		$html='';
		
		$url='index.php?controller=AdminModules&configure='.$this->name.'&token='.Tools::getAdminTokenLite('AdminModules');
		$html.='<a  href="'.$url.'">'.$this->l('My Tasks').'</a>';
		
		
		return $html;
	}
	
	
	
   

  
  
  }

